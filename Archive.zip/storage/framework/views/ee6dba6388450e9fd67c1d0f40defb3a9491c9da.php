

<?php $__env->startSection('title'); ?> <?php echo e($project->meta_title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?> <?php echo e($project->meta_description); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('css/front/magnific.min.css')); ?>" type="text/css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  
   <div class="breadcrumb-area">
   	<div class="container">
   		 <h1 class="breadcrumb-title"><?php echo e($project->meta_title); ?></h1>

   		<ul class="page-list">
            <li class="item-home"><a class="bread-link" href="<?php echo e(route('home')); ?>" title="Home"><?php echo e(clean( trans('niva-backend.home') , array('Attr.EnableID' => true))); ?></a></li>
            <li class="separator separator-home"></li>
            <li class="item-home"><a class="bread-link" href="<?php echo e(route('portfolio')); ?>" title="Home"><?php echo e(clean( trans('niva-backend.our_projects') , array('Attr.EnableID' => true))); ?></a></li>
            <li class="separator separator-home"></li>
            <li class="item-current"><?php echo e($project->meta_title); ?></li>
        </ul>
   	</div>
   </div>

   <div class="project-content">

   		

   		<div class="container">

   			<div class="project__img_single">
	         	<img class="img-fluid thumparallax-down" width="900" height="938" src="<?php echo e($project->image_featured2); ?>">                
	       	</div>

   			<div class="row">
					<div class="col-md-8">
				        <h2 class="post-name"><?php echo e($project->meta_title); ?></h2>
				        <span class="venor-animate-border"></span>
				        <?php echo $project->body; ?>

					</div>
				    <div class="col-md-4">
				        <h4 class="post-name"><?php echo e(clean( trans('niva-backend.info') , array('Attr.EnableID' => true))); ?></h4>
				        <span class="venor-animate-border"></span>
				        
				        <p><strong><?php echo e($project->date); ?></strong></p>
				        <p><strong><?php echo e($project->client); ?></strong></p>
				        <p><strong><?php echo e($project->project_category->name); ?></strong></p>

				        <a href="<?php echo e($project->button_link); ?>" target="_blank" class="btn btn-style1"><span><?php echo e($project->button_text); ?></span></a>
				    </div>
				</div>

				<div class="gallery">
					<div class="row">

						<div class="col-md-6">
							<div class="featured-image">
								<a href="<?php echo e($project->img_gal1); ?>">
									<img class="thumparallax-down img-fluid lazy" src="/public/img/loading-blog.gif" data-src="<?php echo e($project->img_gal1); ?>">
								</a>
							</div>
						</div>

						<div class="col-md-6">
							<div class="featured-image">
								<a href="<?php echo e($project->img_gal2); ?>">
									<img class="thumparallax-down img-fluid lazy" src="/public/img/loading-blog.gif" data-src="<?php echo e($project->img_gal2); ?>">
								</a>
							</div>
						</div>

						<div class="col-md-6">
							<div class="featured-image">
								<a href="<?php echo e($project->img_gal3); ?>">
									<img class="thumparallax-down img-fluid lazy" src="/public/img/loading-blog.gif" data-src="<?php echo e($project->img_gal3); ?>">
								</a>
							</div>
						</div>
						
						<div class="col-md-6">
							<div class="featured-image">
								<a href="<?php echo e($project->img_gal4); ?>">
									<img class="thumparallax-down img-fluid lazy" src="/public/img/loading-blog.gif" data-src="<?php echo e($project->img_gal4); ?>">
								</a>
							</div>
						</div>

					</div>
					
				</div>

   		</div>
   		
   	</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/laravel1.lucian.host/resources/views/project.blade.php ENDPATH**/ ?>