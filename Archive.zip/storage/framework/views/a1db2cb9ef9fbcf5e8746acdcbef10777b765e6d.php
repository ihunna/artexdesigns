

<?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">



    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e($user->name); ?></h6>
        </div>
        <div class="card-body">

                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary btn-back"><?php echo e(clean( trans('niva-backend.back_user') , array('Attr.EnableID' => true))); ?></a>

                <div class="row">
                    <div class="col-md-3">
                        <div class="img-container">
                            <img class="img-fluid" src="/public/images/media/<?php echo e($user->photo ? $user->photo->file : '/public/img/200x200.png'); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-md-9">

                        <form>

                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.name') , array('Attr.EnableID' => true))); ?></strong>
                                        <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control" placeholder="<?php echo e(clean( trans('niva-backend.name') , array('Attr.EnableID' => true))); ?>" readonly="">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.email') , array('Attr.EnableID' => true))); ?></strong>
                                        <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control" placeholder="<?php echo e(clean( trans('niva-backend.email') , array('Attr.EnableID' => true))); ?>" readonly="">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.address') , array('Attr.EnableID' => true))); ?></strong>
                                        <input type="text" name="address" value="<?php echo e($user->address); ?>" class="form-control" placeholder="<?php echo e(clean( trans('niva-backend.address') , array('Attr.EnableID' => true))); ?>" readonly="">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.city') , array('Attr.EnableID' => true))); ?></strong>
                                        <input type="text" name="city" value="<?php echo e($user->city); ?>" class="form-control" placeholder="<?php echo e(clean( trans('niva-backend.city') , array('Attr.EnableID' => true))); ?>" readonly="">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.phone') , array('Attr.EnableID' => true))); ?></strong>
                                        <input type="text" name="phone" value="<?php echo e($user->phone); ?>" class="form-control" placeholder="<?php echo e(clean( trans('niva-backend.phone') , array('Attr.EnableID' => true))); ?>" readonly="">
                                    </div>
                                </div>
                            </div>

                        </form>
                        
                    </div>
                </div>

        </div>
    </div>

</div>
<!-- /.container-fluid -->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/laravel1.lucian.host/resources/views/users/show.blade.php ENDPATH**/ ?>