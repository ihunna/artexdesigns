<?php


return [

    'info' => 'معلومات',

    'all' => 'الجميع',
    'sort_by' => 'ترتيب حسب',
    'call_help' => 'طلب المساعدة:',
    'mail_us' => 'أرسل لنا:',
    'our_address' => 'عنواننا:',
    
    'no_results' => 'لا نتائج',
    'search_text' => 'جرب موضوع ووردبريس',
    'you_searched_for' => 'لقد بحثت عن:',

    'view_project' => 'عرض مشروع', 
    'load_more' => 'تحميل المزيد', 

    'home' => 'الصفحة الرئيسية', 
    'our_projects' => 'مشاريعنا', 
    'our_news' => 'أخبارنا', 
];