<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('css/libs/dropzone.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(clean( trans('niva-backend.upload_image') , array('Attr.EnableID' => true))); ?></h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(clean( trans('niva-backend.upload_image') , array('Attr.EnableID' => true))); ?></h6>
        </div>
        <div class="card-body">


            <a href="<?php echo e(route('media.index')); ?>" class="btn btn-primary btn-back"><?php echo e(clean( trans('niva-backend.back_media') , array('Attr.EnableID' => true))); ?></a>

            <div class="table-responsive">
			    <form action="<?php echo e(route('media.store')); ?>" class="dropzone" method="POST" enctype="multipart/form-data">
			        <?php echo csrf_field(); ?>

			    </form>
            </div>


            <p class="mb-4 mt-4"><?php echo e(clean( trans('niva-backend.accepted_files') , array('Attr.EnableID' => true))); ?></p>  

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

    <script src="<?php echo e(asset('js/libs/dropzone.min.js')); ?>"></script>
    <script type="text/javascript">
        Dropzone.autoDiscover = false;
        var myDropzone = new Dropzone(".dropzone", { 
           maxFilesize: 10,
           acceptedFiles: ".jpeg,.jpg,.png,.gif,.webp,.svg"
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/laravel1.lucian.host/resources/views/media/create.blade.php ENDPATH**/ ?>