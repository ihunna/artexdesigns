<?php $__env->startSection('title'); ?> <?php echo e($portfoliosettings->meta_title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?> <?php echo e($portfoliosettings->meta_description); ?> <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  
  
   <div class="banner-section" data-background-image-url="<?php echo e($portfoliosettings->banner_img ? $portfoliosettings->banner_img : '/public/img/200x200.png'); ?>">

        <div class="container">
            <h1 class="banner-title"><?php echo $portfoliosettings->banner_title; ?></h1>
            <p class="banner-desc"><?php echo $portfoliosettings->banner_desc; ?></p>
        </div>

        <div class="header-social-share">
            <?php echo $headerfooter->social_links; ?>

        </div>

        <a href="#" class="hero__scroll"><svg width="15" height="22.1"><use xlink:href="#scroll"></use></svg></a>
       
   </div>

   <div class="portfolio-section-page light-section">
       <div class="projects-page-row">

                      <?php $count = 1; ?>  
                      <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        

                        <div class="project-row <?php if($count % 2 == 0){ echo 'project-row-right'; } ?>">
                            <div class="project_index">0.<?php echo $count; ?>  </div>
                            <div class="project__img">
                              <img class="img-fluid thumparallax-down" width="900" height="938" src="<?php echo e($project->image_featured2); ?>">                
                            </div>
                            <div class="container">
                                <div class="info-row__info">
                                    <span class="case_tt"><?php echo e($project->project_category->name); ?></span>
                                    <h2 class="info-row__title"><a href="<?php echo e(URL::to('/')); ?>/project/<?php echo e($project->slug); ?>"><?php echo e($project->title); ?></a></h2>
                                    <div class="project-desc">
                                        <?php echo $project->excerpt; ?>

                                    </div>
                                    <div class="project-button">
                                        <a href="<?php echo e(URL::to('/')); ?>/project/<?php echo e($project->slug); ?>" title="<?php echo e($project->title); ?>"><span><?php echo e(clean( trans('niva-backend.view_project') , array('Attr.EnableID' => true))); ?></span><svg viewBox="0 0 80 80"><polyline points="19.89 15.25 64.03 15.25 64.03 59.33"></polyline><line x1="64.03" y1="15.25" x2="14.03" y2="65.18"></line></svg></a>
                                    </div>
                                </div>
                            </div>
                        </div>


                        
                        <?php $count++; ?>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       </div>
   </div>

 

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/laravel1.lucian.host/resources/views/portfolio.blade.php ENDPATH**/ ?>