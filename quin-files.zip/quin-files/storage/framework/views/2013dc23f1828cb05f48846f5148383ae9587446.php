

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('includes.tinyeditor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Begin Page Content -->
<div class="container-fluid">


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(clean( trans('niva-backend.contact_settings') , array('Attr.EnableID' => true))); ?></h1>




                <?php if($message = Session::get('setting_success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>    
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>

                <div class="pb-2 text-right">
                    <?php if(!empty($langs)): ?>
                        <select name="language" class="form-control language-control" onchange="window.location='<?php echo e(url()->current() . '?language='); ?>'+this.value">
                            <option value="" selected disabled><?php echo e(clean( trans('niva-backend.select_language') , array('Attr.EnableID' => true))); ?></option>
                            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($lang->code); ?>" <?php echo e($lang->code == request()->input('language') ? 'selected' : ''); ?>><?php echo e($lang->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php endif; ?>
                </div>



                <?php echo $__env->make('includes.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="row">

                	<div class="col-md-12">


                        <!-- Contact -->
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-dark"><?php echo e(clean( trans('niva-backend.contact_info') , array('Attr.EnableID' => true))); ?></h6>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('contact-setting.update', $setting->id)); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.box_icon') , array('Attr.EnableID' => true))); ?>  <?php echo $setting->box_icon1; ?></strong>
                                                <input type="text" name="box_icon1" class="form-control" value="<?php echo e($setting->box_icon1); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.box_icon') , array('Attr.EnableID' => true))); ?>  <?php echo $setting->box_icon2; ?></strong>
                                                <input type="text" name="box_icon2" class="form-control" value="<?php echo e($setting->box_icon2); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.box_icon') , array('Attr.EnableID' => true))); ?> <?php echo $setting->box_icon3; ?></strong>
                                                <input type="text" name="box_icon3" class="form-control" value="<?php echo e($setting->box_icon3); ?>">
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.box_title') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="box_title1" class="form-control" value="<?php echo e($setting->box_title1); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.box_title') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="box_title2" class="form-control" value="<?php echo e($setting->box_title2); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.box_title') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="box_title3" class="form-control" value="<?php echo e($setting->box_title3); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.box_description') , array('Attr.EnableID' => true))); ?></strong>
                                                <textarea name="box_html1" class="form-control" rows="6"><?php echo e(clean( $setting->box_html1 , array('Attr.EnableID' => true))); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.box_description') , array('Attr.EnableID' => true))); ?></strong>
                                                <textarea name="box_html2" class="form-control" rows="6"><?php echo e(clean( $setting->box_html2 , array('Attr.EnableID' => true))); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.box_description') , array('Attr.EnableID' => true))); ?></strong>
                                                <textarea name="box_html3" class="form-control" rows="6"><?php echo e(clean( $setting->box_html3 , array('Attr.EnableID' => true))); ?></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-md-12 text-right">
                                            <button type="submit" class="btn btn-primary"><?php echo e(clean( trans('niva-backend.update') , array('Attr.EnableID' => true))); ?></button>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                        <!-- Contact -->
                        
                        <!-- Form information -->
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-dark"><?php echo e(clean( trans('niva-backend.form_info') , array('Attr.EnableID' => true))); ?></h6>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('contact-setting.update', $setting->id)); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.title_form') , array('Attr.EnableID' => true))); ?></strong>
                                        <input type="text" name="form_title" class="form-control" value="<?php echo e($setting->form_title); ?>">
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.form_input_text1') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="form_input_name" class="form-control" value="<?php echo e($setting->form_input_name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.form_input_text2') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="form_input_email" class="form-control" value="<?php echo e($setting->form_input_email); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.form_input_text3') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="form_input_budget" class="form-control" value="<?php echo e($setting->form_input_budget); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.form_input_text4') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="form_input_phone" class="form-control" value="<?php echo e($setting->form_input_phone); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.form_message') , array('Attr.EnableID' => true))); ?></strong>
                                        <input type="text" name="form_message" class="form-control" value="<?php echo e($setting->form_message); ?>">
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.button_text') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="button_text" class="form-control" value="<?php echo e($setting->button_text); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.mail_to_email') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="mailto" class="form-control" value="<?php echo e($setting->mailto); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-md-12 text-right">
                                            <button type="submit" class="btn btn-primary"><?php echo e(clean( trans('niva-backend.update') , array('Attr.EnableID' => true))); ?></button>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                        <!-- Form information -->

                        <!-- Sidebar information -->
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-dark"><?php echo e(clean( trans('niva-backend.map_info') , array('Attr.EnableID' => true))); ?></h6>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('contact-setting.update', $setting->id)); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.title') , array('Attr.EnableID' => true))); ?></strong>
                                        <input type="text" name="title" class="form-control" value="<?php echo e($setting->title); ?>">
                                    </div>

                                   <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.map_iframe') , array('Attr.EnableID' => true))); ?></strong>
                                        <textarea name="iframe_txt" class="form-control" rows="10"><?php echo e($setting->iframe_txt); ?></textarea>
                                    </div>


                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-md-12 text-right">
                                            <button type="submit" class="btn btn-primary"><?php echo e(clean( trans('niva-backend.update') , array('Attr.EnableID' => true))); ?></button>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                        <!-- Form information -->


                         <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-dark"><?php echo e(clean( trans('niva-backend.section_clients') , array('Attr.EnableID' => true))); ?></h6>
                            </div>
                            <div class="card-body">
                                <a class="btn btn-primary" href="<?php echo e(route('client.index') . '?language=' . request()->input('language')); ?>"><?php echo e(clean( trans('niva-backend.view_all') , array('Attr.EnableID' => true))); ?></a>
                                <a class="btn btn-primary" href="<?php echo e(route('client.create') . '?language=' . request()->input('language')); ?>"><?php echo e(clean( trans('niva-backend.create') , array('Attr.EnableID' => true))); ?></a>
                            </div>
                        </div>


                        <!-- SEO -->
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-dark"><?php echo e(clean( trans('niva-backend.seo') , array('Attr.EnableID' => true))); ?></h6>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('contact-setting.update', $setting->id)); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.meta_title') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="meta_title" class="form-control" value="<?php echo e($setting->meta_title); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.meta_description') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="meta_description" class="form-control" value="<?php echo e($setting->meta_description); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.slug') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="slug" class="form-control" value="<?php echo e($setting->slug); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.anchor_text') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="breadcrumbs_anchor" class="form-control" value="<?php echo e($setting->breadcrumbs_anchor); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-md-12 text-right">
                                            <button type="submit" class="btn btn-primary"><?php echo e(clean( trans('niva-backend.update') , array('Attr.EnableID' => true))); ?></button>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                        <!-- SEO -->


                		
                	</div>
                </div>



</div>
<!-- /.container-fluid -->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/venor.lucian.host/resources/views/settings/contact/contact-edit.blade.php ENDPATH**/ ?>