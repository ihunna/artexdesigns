<?php $__env->startSection('title'); ?> <?php echo e($pricingsetting->meta_title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?> <?php echo e($pricingsetting->meta_description); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  


   <div class="banner-section" data-background-image-url="<?php echo e($pricingsetting->banner_img ? $pricingsetting->banner_img : '/public/img/200x200.png'); ?>">

        <div class="container">
            <h1 class="banner-title"><?php echo $pricingsetting->banner_title; ?></h1>
            <p class="banner-desc"><?php echo $pricingsetting->banner_desc; ?></p>
        </div>

        <div class="header-social-share">
            <?php echo $headerfooter->social_links; ?>

        </div>

        <a href="#" class="hero__scroll"><svg width="15" height="22.1"><use xlink:href="#scroll"></use></svg></a>
       
   </div>

   	<div class="pricing-elements">

   		<div class="container">

   			<h2><?php echo $pricingsetting->title; ?></h2>
   			<p><?php echo e($pricingsetting->description); ?></p>

	   		<div class="row">

	   			<?php $__currentLoopData = $pricings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pricing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	   			<div class="col-md-4">
	   				<div class="venor-price-box <?php if($pricing->pricing_switch == 1): ?> premium-pricing <?php endif; ?>">
	   					<?php if($pricing->pricing_switch == 1): ?> <div class="plan-ribbon-wrapper"><div class="plan-ribbon"><?php echo e($pricing->popular_text); ?></div></div> <?php endif; ?>
					    <?php echo $pricing->title; ?>

					    <div class="plan-features">
					        <?php echo $pricing->description; ?>

					    </div>
					    <div class="project-button">
							<a href="<?php echo e($pricing->button_link); ?>" title="Web Design"><span><?php echo e($pricing->button_text); ?></span><svg viewBox="0 0 80 80"><polyline points="19.89 15.25 64.03 15.25 64.03 59.33"></polyline><line x1="64.03" y1="15.25" x2="14.03" y2="65.18"></line></svg></a>
						</div>
					</div>
	   			</div>
	   			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	   		</div>
	    </div>
   	</div>
    




<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/laravel1.lucian.host/resources/views/pricing.blade.php ENDPATH**/ ?>